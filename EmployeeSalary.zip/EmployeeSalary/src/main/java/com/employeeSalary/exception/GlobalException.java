package com.employeeSalary.exception;

import com.employeeSalary.entity.ApiResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.Date;

@ControllerAdvice
public class GlobalException {

    @ExceptionHandler(ResourceNotFound.class)
    public ResponseEntity<ApiResponse> resourceNotFoundHandler(ResourceNotFound ex){
        ApiResponse api = new ApiResponse(ex.getMessage(), new Date());

        return new ResponseEntity<>(api, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponse> resourceNotFoundHandler(Exception ex){
        ApiResponse api = new ApiResponse(ex.getMessage(), new Date());

        return new ResponseEntity<>(api, HttpStatus.NOT_FOUND);
    }


}
