package com.employeeSalary.service;

import com.employeeSalary.entity.Employee;

import java.util.List;

public interface EmployeeService {
    //create
    Employee createEmployee(Employee emp);

    //update

    Employee updateEmployee(Employee emp, long id);

    //getAllEmployee

    List<Employee> getAllEmployee();

    //getSingleEmployee

    Employee getSingleEmployee(long id);

    // delete Employee

    void deleteEmployee(long id);





}
