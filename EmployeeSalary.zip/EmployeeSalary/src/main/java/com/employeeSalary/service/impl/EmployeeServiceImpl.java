package com.employeeSalary.service.impl;

import com.employeeSalary.entity.Employee;
import com.employeeSalary.exception.ResourceNotFound;
import com.employeeSalary.repository.EmployeeRepository;
import com.employeeSalary.service.EmployeeService;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfWriter;
import org.springframework.stereotype.Service;

import javax.swing.text.AbstractDocument;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    private EmployeeRepository employeeRepository;

    public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    @Override
    public Employee createEmployee(Employee emp) {
        emp.setGrossSalary(emp.grossSalaryCalculater());
        Employee savedEmployee = employeeRepository.save(emp);

        return savedEmployee;

    }

    @Override
    public Employee updateEmployee(Employee emp, long id) {
        Employee employee = employeeRepository.findById(id).orElseThrow(() -> new ResourceNotFound("Employee not found with id: " + id));

        employee.setName(emp.getName());
        employee.setBasicPay(emp.getBasicPay());
        employee.setPf(emp.getPf());
        employee.setHra(emp.getHra());
        employee.setBonosus(emp.getBonosus());
        employee.setAllowances(emp.getAllowances());
        employee.setType(emp.getType());
        employee.setTax(emp.getTax());
        employee.setPa(emp.getPa());
        employee.setGrossSalary(employee.grossSalaryCalculater());


        Employee updatedEmployee = employeeRepository.save(employee);
        return updatedEmployee;

    }

    @Override
    public List<Employee> getAllEmployee() {
        return employeeRepository.findAll();
    }

    @Override
    public Employee getSingleEmployee(long id) {
        return employeeRepository.findById(id).orElseThrow(() -> new ResourceNotFound("Employee not found with id: " + id));
    }

    @Override
    public void deleteEmployee(long id) {
        Employee employee = employeeRepository.findById(id).orElseThrow(() -> new ResourceNotFound("Employee not found with id: " + id));
        employeeRepository.deleteById(id);

    }

    public ByteArrayInputStream generateSlip(long id){
        Employee employee = employeeRepository.findById(id).orElseThrow(()-> new ResourceNotFound("Employee not Found with id: " + id));
        String Heading = "Salary slip";
        String empName="Name = "+employee.getName();
        String basicPay="Basic Pay = "+employee.getBasicPay();
        String allowances = "Allowances = "+employee.getAllowances();
        String type = "Employment type= "+employee.getType();
        String hra = "HRA = "+employee.getHra();
        String pa = "PA = "+employee.getPa();
        String bonus = "Bonosus = "+employee.getBonosus();
        String tax = "Tax = "+employee.getTax();
        String gross = "Gross salary = "+employee.getGrossSalary();
        String pf = "PF = "+employee.getPf();
        String l = "------------------------------";


        ByteArrayOutputStream out = new ByteArrayOutputStream();
        Document document = new Document();
        PdfWriter.getInstance(document,out);

        document.open();
        Paragraph pt = new Paragraph(Heading);
        pt.setAlignment(Element.ALIGN_CENTER);

        document.add(pt);

        Paragraph name = new Paragraph(empName);
        Paragraph allowance = new Paragraph(allowances);
        Paragraph bp = new Paragraph(basicPay);
        Paragraph t = new Paragraph(type);
        Paragraph Hra = new Paragraph(hra);
        Paragraph Pa = new Paragraph(pa);
        Paragraph bon = new Paragraph(bonus);
        Paragraph taxx = new Paragraph(tax);
        Paragraph pff = new Paragraph(pf);
        Paragraph line = new Paragraph(l);
        Paragraph g = new Paragraph(gross);

        document.add(name);
        document.add(t);
        document.add(bp);
        document.add(Hra);
        document.add(Pa);
        document.add(allowance);
        document.add(bon);
        document.add(taxx);
        document.add(pff);
        document.add(line);
        document.add(g);












        document.close();
        return new ByteArrayInputStream(out.toByteArray());
    }
}
