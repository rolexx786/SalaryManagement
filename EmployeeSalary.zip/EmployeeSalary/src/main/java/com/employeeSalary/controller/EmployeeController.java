package com.employeeSalary.controller;

import com.employeeSalary.entity.Employee;
import com.employeeSalary.service.EmployeeService;
import com.employeeSalary.service.impl.EmployeeServiceImpl;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.io.ByteArrayInputStream;
import java.util.List;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

    private EmployeeServiceImpl employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = (EmployeeServiceImpl) employeeService;
    }
    //create

    @PostMapping
    public ResponseEntity<Employee> createEmp(@RequestBody Employee emp){
        Employee employee = employeeService.createEmployee(emp);
        return new ResponseEntity<>(employee, HttpStatus.CREATED);
    }

    //update
    @PutMapping("/update/{eid}")
    public ResponseEntity<Employee> updateEmployee(@RequestBody Employee emp, @PathVariable long eid){
        Employee updated = employeeService.updateEmployee(emp, eid);
        return new ResponseEntity<>(updated, HttpStatus.OK);
    }


    //getsingle

    @GetMapping("/{eid}")
    public ResponseEntity<Employee> getEmployee(@PathVariable long eid){
        Employee singleEmployee = employeeService.getSingleEmployee(eid);
        return new ResponseEntity<>(singleEmployee, HttpStatus.OK);
    }


    //getall
    @GetMapping
    public ResponseEntity<List<Employee>> getAllEmployee(){
        List<Employee> allEmployee = employeeService.getAllEmployee();

        return  new ResponseEntity<>(allEmployee, HttpStatus.OK);
    }


    //delete

    @DeleteMapping("/{eid}")
    public ResponseEntity<String> deleteEmployee(@PathVariable long eid){
        employeeService.deleteEmployee(eid);

        return new ResponseEntity<>("Employee Record is Deleted Successfully", HttpStatus.OK);
    }

    //generate pdf

    @PostMapping("/slip/{eid}")
    public ResponseEntity<InputStreamResource> createPdf(@PathVariable long eid){
        ByteArrayInputStream pdf = employeeService.generateSlip(eid);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Content-Disposition", "inline,file=bokari.pdf");
        return ResponseEntity.ok().headers(httpHeaders).contentType(MediaType.APPLICATION_PDF).body(new InputStreamResource(pdf));
    }



}
