package com.employeeSalary.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.security.Identity;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String name;
    private String type;
    private long basicPay;
    private long hra;
    private long pa;
    private long allowances;
    private long bonosus;
    private long tax;
    private long pf;
    private long grossSalary;

    public long grossSalaryCalculater(){
        long total = basicPay+hra+pa+allowances+bonosus+tax+pf;
        return total;
    }


}
